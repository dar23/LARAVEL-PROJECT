<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\HumorController;
use App\Http\Controllers\NewsyController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/',[MainController::class,'show']);
Route::post('form_get',[MainController::class,'store']);



Route::get('/newsy',[NewsyController::class,'showNewsy']);
Route::post('/form_get_0',[NewsyController::class,'store_0']);



Route::get('/humor',[HumorController::class,'showHumor']);
Route::post('/form_get_1',[HumorController::class,'store_1']);