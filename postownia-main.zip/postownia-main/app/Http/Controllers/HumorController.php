<?php

namespace App\Http\Controllers;
use App\Models\postshumor;
use Illuminate\Http\Request;

class HumorController extends Controller
{
    //
    public function showHumor(){

        $postshumor=postshumor::all();

            return view('humor',['postshumor'=>$postshumor]); 
                       
                    }



    public function store_1(request $request ){
                       
          
                        //zapis do folderu obrazka

             $filename=$request->file('newPicture_1')->getClientOriginalName();  //pobranie nazwy 
             $request->file('newPicture_1')->move('images', $filename);
         
             //zapisanie obrazka w folderze apki
            //tworzy się cały czas nowa ścieżka ze zmiennej $patch;
     
                       $new_post_1= new postshumor();
                       $new_post_1->imageHumor=$filename;
                       $new_post_1->save();
                       
     
                              return redirect('humor');
     
     
     
                     }
























}
