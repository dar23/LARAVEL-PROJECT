<?php

namespace App\Http\Controllers;
use App\Models\Newpaper;
use Illuminate\Http\Request;

class NewsyController extends Controller
{


    //
    public function showNewsy(){

        $messages=Newpaper::all();

            return view('newsy')->with('newpapers',$messages); 
        
                    }
                   


    public function store_0(request $request ){
                       
          
                        //zapis do folderu obrazka

             $filename=$request->file('newPicture_0')->getClientOriginalName();  //pobranie nazwy 
             $request->file('newPicture_0')->move('images', $filename);
         
             //zapisanie obrazka w folderze apki
            //tworzy się cały czas nowa ścieżka ze zmiennej $patch;
     
                       $new_post_1= new Newpaper();
                       $new_post_1->imageNews=$filename;
                       $new_post_1->save();
                       
     
                              return redirect('newsy');
     
     
     
                     }






}
