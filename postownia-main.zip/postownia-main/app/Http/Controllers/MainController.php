<?php

namespace App\Http\Controllers;
use App\Models\Post;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;




class MainController extends Controller{
                    
    
    
public function show() {

         $posts=Post::all();

            return view('main',['posts'=>$posts]);
                       
                    }







public function store(request $request )
                    {
         
                      


                        $filename=$request->file('newPicture')->getClientOriginalName();  
                        $request->file('newPicture')->move('images', $filename);
                    

                  $new_post= new Post();
                  $new_post->content=$request->input('new_text');
                  $new_post->image=$filename;
                  $new_post->save();
                  
                         return redirect('/');

          


                }






                    }









           
                