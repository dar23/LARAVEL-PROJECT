
function open_form(){

        let admin_open=document.querySelector('.form_main');
        
        

             admin_open.style.display="block";
             admin_open.style.animation="fadein 0.5s forwards";



}
function close_form(){

        let admin_open=document.querySelector('.form_main');
             admin_open.style.animation="fadeout 0.1s forwards";
             admin_open.style.display="none"; 
                  

}


