<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=M+PLUS+2&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{url('css/main.css')}}" />
    <link rel="stylesheet" href="{{url('css/registerlog.css')}}" />
    <link rel="stylesheet" href="{{url('css/menu.css')}}" />  
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <script type="text/javascript" src="{{ URL::asset('js/main.js') }}"></script>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=M+PLUS+2&display=swap" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dream heaven</title>
</head>
<body onload="newFunction()">



<nav>
      
      <label class="logo">  AMAZING SITE  </label>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="newsy">newsy</a></li>
        <li><a href="#">trening</a></li>
        <li><a href="#">muzyka</a></li>
        <li><a href="humor">humor</a></li>
        <li><a href="#">kodowanie</a></li>
        <li><a href="#">projekty</a></li>
        <li><a href="#">przydatne linki</a></li>
        <li><span class="administracja" onclick="open_form()">administracja</span></li>
        <li><a href="#">o mnie</a></li>
      </ul>
    </nav>



<br>






















<div class="container">

      @foreach ($posts as $post)
                    
                    
      <div class="newPost">   
                    
          <img src="{{asset('images/'.$post->image)}}" class="main_img" >
              <br>
                  <br>
                      <span class="text"> {{$post->content}} </span>
      </div>   
                

       @endforeach      
              
      

      <form method="post"  action="form_get" enctype="multipart/form-data" class="form_main">  
             @csrf

            



                 <textarea type="textarea" name="new_text" ></textarea><br>
                       <input type="file" name="newPicture" class="input_file">
                            <input type="submit" value="wyślij" class="submit_send"/>
                                <label class="file_label" for="file"></label>


                                <button type="button" class="close" aria-label="Close" onclick="close_form()">
                                      <span aria-hidden="true">zamknij</span>
                                              </button>



        
      </form>


</div>





  












<!--usuwanie i wracanie pętli powoduje że wyświetla mi dane
w przeciwnym razie pokazuje że nie ma zdefiniowanej zmiennej $posts-->





</body>
</html>