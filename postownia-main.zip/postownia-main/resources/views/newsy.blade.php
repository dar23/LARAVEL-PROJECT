<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <link rel="stylesheet" href="{{url('css/newsy.css')}}" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=M+PLUS+2&display=swap" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THE SKY</title>
</head>
<body>




 
    <form method="post"  action="form_get_0" enctype="multipart/form-data">   
        @csrf
        
                <textarea type="textarea" name="new_text" class="input_file_0"></textarea><br>
                <input type="file" name="newPicture_0" class="input_file_newsy">
                <input type="submit" value="wyślij" class="submit_send_0" />
                <label class="file_label" for="file"></label>
                
        </form>


  

<br>



<div class="container">


   
@foreach($newpapers as $picture)
      
       
   <div class="newPost">   
      
       <img src="{{asset('images/'.$picture->imageNews)}}" class="main_img" >
         <br>
           <br>
        
                </div>   
   
@endforeach        

     



  
</div>














<!--usuwanie i wracanie pętli powoduje że wyświetla mi dane
w przeciwnym razie pokazuje że nie ma zdefiniowanej zmiennej $posts-->





</body>
</html>