<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   
    <link rel="stylesheet" href="{{url('css/humor.css')}}" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post"  action="form_get_1" enctype="multipart/form-data">   
        @csrf
        
        <input type="file" name="newPicture_1" class="input_file_1">
                <input type="submit" value="wyślij" class="submit_send_1"/>
                <label class="file_label" for="file"></label>
                

            
        </form>



<div class="container">


   
@foreach ($postshumor as $post)
      
    

    <div class="meme_window" width="30%" >

        <img src="{{asset('images/'.$post->imageHumor)}}"  >
      
    </div>  
                

          
@endforeach        

     



  
</div>














    
</body>
</html>